
<?php $__env->startSection('content'); ?>
 
 
<div class="card">
  <div class="card-header">VIEW HUMAN</div>
  <div class="card-body">
   
 
        <div class="card-body">
        <h5 class="card-title">Name : <?php echo e($leyva->name); ?></h5>
        <h6 class="card-text">Address : <?php echo e($leyva->address); ?></h6>
        <h7 class="card-text">Phone : <?php echo e($leyva->mobile); ?></h7>
  </div>
       
    </hr>
  
  </div>
</div>
<?php echo $__env->make('leyva.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leyva\resources\views/leyva/show.blade.php ENDPATH**/ ?>
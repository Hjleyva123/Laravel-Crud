
<?php $__env->startSection('content'); ?>
 
<div class="card">
  <div class="card-header">CREATE ANOTHER HUMAN</div>
  <div class="card-body">
      
      <form action="<?php echo e(url('leyva/' .$leyva->id)); ?>" method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PATCH"); ?>
        <input type="hidden" name="id" id="id" value="<?php echo e($leyva->id); ?>" id="id" />
        <label>Name</label></br>
        <input type="text" name="name" id="name" value="<?php echo e($leyva->name); ?>" class="form-control"></br>
        <label>Address</label></br>
        <input type="text" name="address" id="address" value="<?php echo e($leyva->address); ?>" class="form-control"></br>
        <label>Mobile</label></br>
        <input type="text" name="mobile" id="mobile" value="<?php echo e($leyva->mobile); ?>" class="form-control"></br>
        <input type="hidden" name="fee" id="id" value="<?php echo e($leyva->id); ?>" id="id" />
        <input type="submit" value="UPDATE HUMAN" class="btn btn-success"></br>
    </form>   
   
  </div>
</div>
 

<?php echo $__env->make('leyva.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leyva\resources\views/leyva/edit.blade.php ENDPATH**/ ?>
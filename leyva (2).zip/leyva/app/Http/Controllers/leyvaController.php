<?php

namespace App\Http\Controllers;
use App\Models\leyva;
use Illuminate\Http\Request;

class leyvaController extends Controller
{
  
    public function index()
    {
        $leyva = leyva::all();
      return view ('leyva.index')->with('leyva', $leyva);
    }

    
    public function create()
    {
        return view('leyva.create');


    }

   
    public function store(Request $request)
    {
        $input = $request->all();
        leyva::create($input);
        return redirect('leyva')->with('flash_message', 'leyva Addedd!');  
    }

    
    public function show($id)
    {
        $leyva = leyva::find($id);
        return view('leyva.show')->with('leyva', $leyva);
    }

    
    public function edit($id)
    {
        $leyva = leyva::find($id);
        return view('leyva.edit')->with('leyva', $leyva);
    }

  
    public function update(Request $request, $id)
    {
        $leyva = leyva::find($id);
        $input = $request->all();
        $leyva->update($input);
        return redirect('leyva')->with('flash_message', 'leyva Updated!');  
    }

   
    public function destroy($id)
    {
        leyva::destroy($id);
        return redirect('leyva')->with('flash_message', 'leyva deleted!');  
    }
}
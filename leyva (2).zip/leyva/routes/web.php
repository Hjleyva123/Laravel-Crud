<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\leyvaController;


Route::get('/', function () {
    return view('welcome');
});

Route::resource('leyva','App\Http\Controllers\leyvaController');
@extends('leyva.layout')
@section('content')
 
 
<div class="card">
  <div class="card-header">VIEW HUMAN</div>
  <div class="card-body">
   
 
        <div class="card-body">
        <h5 class="card-title">Name : {{ $leyva->name }}</h5>
        <h6 class="card-text">Address : {{ $leyva->address }}</h6>
        <h7 class="card-text">Phone : {{ $leyva->mobile }}</h7>
  </div>
       
    </hr>
  
  </div>
</div>
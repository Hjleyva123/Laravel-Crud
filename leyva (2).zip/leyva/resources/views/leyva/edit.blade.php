@extends('leyva.layout')
@section('content')
 
<div class="card">
  <div class="card-header">CREATE ANOTHER HUMAN</div>
  <div class="card-body">
      
      <form action="{{ url('leyva/' .$leyva->id) }}" method="post">
        {!! csrf_field() !!}
        @method("PATCH")
        <input type="hidden" name="id" id="id" value="{{$leyva->id}}" id="id" />
        <label>Name</label></br>
        <input type="text" name="name" id="name" value="{{$leyva->name}}" class="form-control"></br>
        <label>Address</label></br>
        <input type="text" name="address" id="address" value="{{$leyva->address}}" class="form-control"></br>
        <label>Mobile</label></br>
        <input type="text" name="mobile" id="mobile" value="{{$leyva->mobile}}" class="form-control"></br>
        <input type="hidden" name="fee" id="id" value="{{$leyva->id}}" id="id" />
        <input type="submit" value="UPDATE HUMAN" class="btn btn-success"></br>
    </form>   
   
  </div>
</div>
 
